Code Explanation

Alert Fetching and Tracking:
Fetches alerts from Kibana for the last 5 minutes.
Tracks the number of alerts in the past 24 hours for each server, saving them in alert_tracker.json.

Connectivity Checks:
Ping Check: Checks if the server is reachable via ping.
RDP or SSH Check: Based on the OS (dummy check included here), it tries to establish an RDP (for Windows) or SSH (for Linux) connection.

Reboot Logic:
If both ping and RDP/SSH checks fail:
If there are more than 3 alerts in 24 hours, escalate by email.
Otherwise, attempt to reboot the server using SCVMM with PowerShell.

PowerShell Reboot:
Uses PowerShell to issue a reboot command through SCVMM for the VM.

Requirements
SCVMM PowerShell Module installed.
SMTP Server configured for sending escalation emails.