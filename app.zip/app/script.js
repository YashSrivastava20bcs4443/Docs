async function applyFilter() {
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;
    const portal = document.getElementById('portal').value;
    const tfnType = document.getElementById('tfn-type').value;

    const queryParams = new URLSearchParams({ startDate, endDate, portal, tfnType }).toString();

    try {
        const response = await fetch(`http://localhost:3000/api/stats?${queryParams}`);
        if (!response.ok) throw new Error('Network response was not ok');

        const data = await response.json();
        updateDashboard(data);
    } catch (error) {
        console.error('Error fetching stats:', error);
    }
}

function updateDashboard(data) {
    document.getElementById('ivr_offered').textContent = data.ivr_offered || 0;
    document.getElementById('ivr_abandoned').textContent = data.ivr_abandoned || 0;
    document.getElementById('queue_abandoned').textContent = data.queue_abandoned || 0;
    document.getElementById('closed_by_ivr').textContent = data.closed_by_ivr || 0;
    document.getElementById('abandoned_under_10').textContent = data.abandoned_in_10_sec || 0;
    document.getElementById('abandoned_over_10').textContent = data.abandoned_in_over_10_sec || 0;
    document.getElementById('answered_calls').textContent = data.answered_calls || 0;
    updateChart(data);
}

function openDetailPage(type) {
    window.open(`detail.html?type=${type}`, '_blank');
}

function updateChart(data) {
    const ctx = document.getElementById('callChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['IVR Offered', 'IVR Abandoned', 'Queue Abandoned', 'Closed by IVR', 'Abandoned <10s', 'Abandoned >10s', 'Answered Calls'],
            datasets: [{
                label: 'Call Stats',
                data: [data.ivr_offered, data.ivr_abandoned, data.queue_abandoned, data.closed_by_ivr, data.abandoned_in_10_sec, data.abandoned_in_over_10_sec, data.answered_calls],
                backgroundColor: ['blue', 'red', 'orange', 'purple', 'pink', 'brown', 'green']
            }]
        }
    });
}
