const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
    host: '10.7.32.134',
    user: 'postgres',
    password: 'automation@123',
    database: 'postgres',
    port: 5432
});

// 📌 API for Summary Cards
app.get('/api/stats', async (req, res) => {
    try {
        const { startDate, endDate, portal, tfn } = req.query;

        const query = `
            SELECT
                COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4') AS ivr_offered,
                COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric = 0 AND "abandoned" = 'True' AND "preQueueSeconds"::numeric > 0) AS ivr_abandoned,
                COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric > 0 AND "abandoned" = 'True') AS queue_abandoned,
                COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric = 0 AND "abandoned" = 'False' AND "preQueueSeconds"::numeric > 0) AS closed_by_ivr,
                COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "abandoned" = 'False' AND "agentSeconds"::numeric > 0) AS answered_calls
            FROM contact_mapped_data
            WHERE to_date("contactStartDate", 'YYYY-MM-DD') BETWEEN $1 AND $2
            AND ("portal" = $3 OR $3 IS NULL)
            AND ("TFN Type" = $4 OR $4 IS NULL);
        `;

        const result = await pool.query(query, [startDate, endDate, portal || null, tfn || null]);
        res.json(result.rows[0]);

    } catch (err) {
        console.error('Error fetching stats:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// 📌 API for Detailed View Data
app.get('/api/details', async (req, res) => {
    try {
        const { category } = req.query;

        const query = `
            SELECT "contactId" AS call_id, "fromAddress" AS caller, "contactStartDate" AS time, '${category}' AS status
            FROM contact_mapped_data
            WHERE "mediaTypeId" = '4'
            LIMIT 100;
        `;

        const result = await pool.query(query);
        res.json(result.rows);

    } catch (err) {
        console.error('Error fetching details:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
