# accept-legal-terms.sh
az login
az vm image terms accept --publisher fortinet --offer fortinet_fortigate-vm_v5 --plan fortinet_fg-vm

terraform init
terraform apply -auto-approve
