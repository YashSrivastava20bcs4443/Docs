# Variables
$resourceGroupName = "demo-resource-YS"
$dnsZoneName = "my.internal.dns"
$csvFilePath = "/home/yash/records.csv"

# Import CSV
$records = Import-Csv -Path $csvFilePath

# Loop through each record and create DNS records
foreach ($record in $records) {
    $recordName = $record.RecordName
    $ip = $record.IP

    # Debug output
    Write-Output "Creating A record: $recordName with IP: $ip in DNS Zone: $dnsZoneName under Resource Group: $resourceGroupName"

    # Create A record
    $command = "az network private-dns record-set a add-record --resource-group $resourceGroupName --zone-name $dnsZoneName --record-set-name $recordName --ipv4-address $ip"
    Invoke-Expression $command

    # Check for errors
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to create A record: $recordName"
    }
}
