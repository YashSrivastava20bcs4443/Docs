import json
import pandas as pd
import sys
import os

def load_json_data(json_file):
    """Load data from JSON file."""
    if not os.path.exists(json_file):
        print(f"Error: {json_file} does not exist.")
        sys.exit(1)
    
    with open(json_file, 'r') as f:
        data = json.load(f)
    return data

def generate_excel_report(data, output_file):
    """Generate Excel report from the compliance data."""
    # Create a DataFrame from the JSON data
    df = pd.DataFrame([data])

    # Renaming columns for a better report structure
    df.rename(columns={
        'os_version': 'OS Version',
        'sentinelone_status': 'SentinelOne Status and Version',
        'syslog_status': 'Syslog Status',
        'security_updates': 'Security Updates Installed',
        'linux_activation_status': 'Linux Activation Status'
    }, inplace=True)

    # Save the DataFrame to an Excel file
    df.to_excel(output_file, index=False)
    print(f"Compliance report generated and saved to {output_file}")

if __name__ == "__main__":
    # Check if the script is called with the correct arguments
    if len(sys.argv) != 3:
        print("Usage: python3 generate_linux_report.py <input_json> <output_excel>")
        sys.exit(1)

    json_file = sys.argv[1]
    output_file = sys.argv[2]

    # Load JSON data
    compliance_data = load_json_data(json_file)

    # Generate Excel report
    generate_excel_report(compliance_data, output_file)
