import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import DashboardPage from './pages/DashboardPage';
import IvrBucketPage from './pages/IvrBucketPage';
import TfnWisePage from './pages/TfnWisePage';

function App() {
  return (
    <Router>
      <div>
        <header style={headerStyle}>
          <div style={logoStyle}>My Dashboard</div>
          <nav>
            <ul style={navListStyle}>
              <li style={navItemStyle}><Link to="/">Dashboard</Link></li>
              <li style={navItemStyle}><Link to="/ivr-bucket">IVR Bucket</Link></li>
              <li style={navItemStyle}><Link to="/tfn-wise">TFN-Wise</Link></li>
            </ul>
          </nav>
        </header>
        <div style={{ padding: '20px' }}>
          <Switch>
            <Route exact path="/" component={DashboardPage} />
            <Route path="/ivr-bucket" component={IvrBucketPage} />
            <Route path="/tfn-wise" component={TfnWisePage} />
          </Switch>
        </div>
      </div>
    </Router>
  );
}

const headerStyle = {
  backgroundColor: '#003366',
  color: '#fff',
  padding: '20px',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center'
};

const logoStyle = {
  fontSize: '24px',
  fontWeight: 'bold'
};

const navListStyle = {
  listStyle: 'none',
  display: 'flex',
  margin: 0,
  padding: 0
};

const navItemStyle = {
  margin: '0 10px'
};

export default App;
