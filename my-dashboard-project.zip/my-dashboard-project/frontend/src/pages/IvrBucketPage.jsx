import React, { useEffect, useState } from "react";
import axios from "axios";

const IvrBucketPage = () => {
  const [data, setData] = useState([]);

  const fetchIvrData = async () => {
    try {
      const res = await axios.get("/api/ivr-bucket");
      setData(res.data);
    } catch (error) {
      console.error("Error fetching IVR Bucket data:", error);
    }
  };

  useEffect(() => {
    fetchIvrData();
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>IVR Bucket Data</h2>
      <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #ccc" }}>
        <thead>
          <tr>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Time Interval</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Offered Calls</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>IVR Abandoned</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>0-30 Seconds</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>30-60 Seconds</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>60-120 Seconds</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>{'>'}120 Seconds</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => (
            <tr key={index}>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.time_interval}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.offered_calls}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.ivr_abandon}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row["0-30 Seconds"]}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row["30-60 Seconds"]}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row["60-120 Seconds"]}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row[">120 Seconds"]}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default IvrBucketPage;
