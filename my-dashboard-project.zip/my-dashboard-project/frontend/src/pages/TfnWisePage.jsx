import React, { useEffect, useState } from "react";
import axios from "axios";

const TfnWisePage = () => {
  const [data, setData] = useState([]);

  const fetchTfnData = async () => {
    try {
      const res = await axios.get("/api/tfn-wise");
      setData(res.data);
    } catch (error) {
      console.error("Error fetching TFN-Wise data:", error);
    }
  };

  useEffect(() => {
    fetchTfnData();
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>TFN-Wise Data</h2>
      <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #ccc" }}>
        <thead>
          <tr>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Number (toAddress)</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Offered Calls</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Answered</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>IVR Abandon</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Queue Abandon</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Polite Disconnect</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => (
            <tr key={index}>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.Number}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.offered_calls}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.answered}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.ivr_abandon}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.queue_abandon}</td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>{row.polite_disconnect}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TfnWisePage;
