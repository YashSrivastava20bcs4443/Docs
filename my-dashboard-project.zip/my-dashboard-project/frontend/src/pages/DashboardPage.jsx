import React from 'react';

const DashboardPage = () => {
  return (
    <div className="container" style={containerStyle}>
      {/* Filter Panel */}
      <section className="filter-panel" style={filterPanelStyle}>
        <form style={filterFormStyle}>
          <div>
            <label htmlFor="start-date">Start Date:</label>
            <input type="date" id="start-date" name="start-date" />
          </div>
          <div>
            <label htmlFor="end-date">End Date:</label>
            <input type="date" id="end-date" name="end-date" />
          </div>
          <div>
            <label htmlFor="start-time">Start Time:</label>
            <input type="time" id="start-time" name="start-time" />
          </div>
          <div>
            <label htmlFor="end-time">End Time:</label>
            <input type="time" id="end-time" name="end-time" />
          </div>
          <div>
            <label htmlFor="portal">Portal:</label>
            <select id="portal" name="portal">
              <option value="">Select</option>
              <option value="CheapOair">CheapOair</option>
              <option value="OneTravel">One Travel</option>
              <option value="SupportTFN">Support TFN</option>
              <option value="CheapOairSP">CheapOair-SP</option>
              <option value="CheapOairCA">CheapOair.ca</option>
              <option value="Farebuzz">Farebuzz</option>
            </select>
          </div>
          <div>
            <label htmlFor="tfn-type">TFN Type:</label>
            <select id="tfn-type" name="tfn-type">
              <option value="">Select</option>
              <option value="Marketing">Marketing</option>
              <option value="NonMarketing">Non-Marketing</option>
              <option value="SupportTFN">Support TFN</option>
            </select>
          </div>
          <div>
            <button type="submit">Apply Filter</button>
          </div>
        </form>
      </section>
      
      {/* Summary Cards */}
      <section className="summary-cards" style={summaryCardsStyle}>
        <div className="card" style={cardStyle}>
          <h3>IVR Offered</h3>
          <p>1,234</p>
        </div>
        <div className="card" style={cardStyle}>
          <h3>IVR Abandoned</h3>
          <p>567</p>
        </div>
        <div className="card" style={cardStyle}>
          <h3>Queue Abandoned</h3>
          <p>89</p>
        </div>
        <div className="card" style={cardStyle}>
          <h3>Closed by IVR</h3>
          <p>456</p>
        </div>
        <div className="card" style={cardStyle}>
          <h3>Abandoned in 10 Sec</h3>
          <p>123</p>
        </div>
        <div className="card" style={cardStyle}>
          <h3>Abandoned in &gt;10 Sec</h3>
          <p>44</p>
        </div>
        <div className="card" style={cardStyle}>
          <h3>Answered Calls</h3>
          <p>789</p>
        </div>
      </section>
      
      {/* Chart Section */}
      <section className="chart-container" style={chartContainerStyle}>
        <div className="chart-placeholder" style={chartPlaceholderStyle}>
          Chart Placeholder
        </div>
      </section>
      
      {/* Data Table */}
      <section>
        <table className="data-table" style={dataTableStyle}>
          <thead>
            <tr>
              <th>TFN</th>
              <th>Description</th>
              <th>IVR Offered</th>
              <th>IVR Abandoned</th>
              <th>Queue Abandoned</th>
              <th>Closed by IVR</th>
              <th>Answered Calls</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>6467384820</td>
              <td>Default Desktop Home Page Flight</td>
              <td>1234</td>
              <td>567</td>
              <td>89</td>
              <td>456</td>
              <td>789</td>
            </tr>
            <tr>
              <td>6467384933</td>
              <td>Booking Conf. Page & Email</td>
              <td>2345</td>
              <td>678</td>
              <td>90</td>
              <td>567</td>
              <td>890</td>
            </tr>
          </tbody>
        </table>
      </section>
    </div>
  );
};

const containerStyle = {
  maxWidth: '1200px',
  margin: '20px auto',
  padding: '20px',
  backgroundColor: '#fff',
  borderRadius: '8px'
};

const filterPanelStyle = {
  padding: '20px',
  border: '1px solid #ccc',
  borderRadius: '8px',
  marginBottom: '20px',
  backgroundColor: '#f9f9f9'
};

const filterFormStyle = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: '20px',
  alignItems: 'flex-end'
};

const summaryCardsStyle = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: '20px',
  marginBottom: '20px'
};

const cardStyle = {
  flex: '1',
  minWidth: '180px',
  backgroundColor: '#e9ecef',
  padding: '20px',
  borderRadius: '8px',
  textAlign: 'center'
};

const chartContainerStyle = {
  marginBottom: '20px'
};

const chartPlaceholderStyle = {
  backgroundColor: '#ddd',
  height: '300px',
  borderRadius: '8px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '24px',
  color: '#555'
};

const dataTableStyle = {
  width: '100%',
  borderCollapse: 'collapse',
  border: '1px solid #ccc'
};

export default DashboardPage;
