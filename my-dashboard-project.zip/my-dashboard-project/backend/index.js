const express = require("express");
const bodyParser = require("body-parser");
const dataRoutes = require("./routes/dataRoutes");

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use("/api", dataRoutes);

app.listen(port, () => {
  console.log(`Backend server running at http://localhost:${port}`);
});
