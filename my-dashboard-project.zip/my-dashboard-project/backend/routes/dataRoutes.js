const express = require("express");
const router = express.Router();
const pool = require("../config/db");

// ------------------------------
// TFN-Wise Query Endpoint
// ------------------------------
router.get("/tfn-wise", async (req, res) => {
  try {
    const query = `
      SELECT 
          "toAddress" AS "Number",
          COUNT(*) AS offered_calls,
          SUM(CASE 
                  WHEN CAST(NULLIF("abandoned", '') AS BOOLEAN) = FALSE 
                       AND NULLIF("agentSeconds", '') ~ '^[0-9]+(\\.[0-9]+)?$'  
                  THEN NULLIF("agentSeconds", '')::FLOAT::INTEGER ELSE 0 
              END) AS answered,
          SUM(CASE 
                  WHEN CAST(NULLIF("abandoned", '') AS BOOLEAN) = TRUE 
                       AND (NULLIF("inQueueSeconds", '') IS NULL OR NULLIF("inQueueSeconds", '') = '' OR NULLIF("inQueueSeconds", '')::FLOAT::INTEGER = 0) 
                  THEN 1 ELSE 0 
              END) AS ivr_abandon,
          SUM(CASE 
                  WHEN CAST(NULLIF("abandoned", '') AS BOOLEAN) = TRUE 
                       AND NULLIF("inQueueSeconds", '') ~ '^[0-9]+(\\.[0-9]+)?$'  
                  THEN NULLIF("inQueueSeconds", '')::FLOAT::INTEGER ELSE 0 
              END) AS queue_abandon,
          SUM(CASE 
                  WHEN CAST(NULLIF("abandoned", '') AS BOOLEAN) = TRUE 
                       AND "endReason" IN ('Contact Hung Up', 'Contact Hang Up via Script') 
                  THEN 1 ELSE 0 
              END) AS polite_disconnect
      FROM contact_data
      WHERE "MediaType" = '4'
        AND "isOutbound" = 'false'
        AND "MasterContactId" = "ContactId"
      GROUP BY "toAddress"
      ORDER BY offered_calls DESC;
    `;
    const result = await pool.query(query);
    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching TFN-Wise data:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ------------------------------
// IVR Bucket Query Endpoint
// ------------------------------
router.get("/ivr-bucket", async (req, res) => {
  try {
    const query = `
      WITH processed_data AS (
          SELECT 
              TO_TIMESTAMP("contactStartDate", 'YYYY-MM-DD HH24:MI:SS') AS contact_start_time,
              "toAddress",
              "abandoned",
              COALESCE(NULLIF("preQueueSeconds", '')::FLOAT::INTEGER, 0) AS ivr_duration
          FROM contact_data
          WHERE "contactStartDate" IS NOT NULL
      )
      SELECT 
          DATE_TRUNC('hour', contact_start_time) AS time_interval,  
          COUNT(*) AS offered_calls,  
          SUM(CASE WHEN abandoned = 'true' THEN 1 ELSE 0 END) AS ivr_abandon,
          SUM(CASE WHEN ivr_duration BETWEEN 0 AND 30 THEN 1 ELSE 0 END) AS "0-30 Seconds",
          SUM(CASE WHEN ivr_duration BETWEEN 31 AND 60 THEN 1 ELSE 0 END) AS "30-60 Seconds",
          SUM(CASE WHEN ivr_duration BETWEEN 61 AND 120 THEN 1 ELSE 0 END) AS "60-120 Seconds",
          SUM(CASE WHEN ivr_duration > 120 THEN 1 ELSE 0 END) AS ">120 Seconds"
      FROM processed_data
      GROUP BY time_interval
      ORDER BY time_interval;
    `;
    const result = await pool.query(query);
    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching IVR Bucket data:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
