```python
import requests
import appinsight_report_config
import json
from datetime import datetime, timedelta, timezone
from azure.identity import ClientSecretCredential
from msal import ConfidentialClientApplication
import pandas as pd
import smtplib
from io import BytesIO
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Tenant ID, Client ID, and Client Secret
tenant_id = appinsight_report_config.TENANT_ID
client_id = appinsight_report_config.CLIENT_ID
client_secret = appinsight_report_config.CLIENT_SECRET
user_id = appinsight_report_config.USER_ID
app_insights_api_key = appinsight_report_config.APP_INSIGHTS_API_KEY  # Application Insights API key
app_insights_resource_map = appinsight_report_config.APP_INSIGHTS_RESOURCE_MAP  # Dict mapping targetResourceName to appId

# Azure credentials
credential = ClientSecretCredential(tenant_id, client_id, client_secret)

# Get access token
access_token = credential.get_token("https://management.azure.com/.default").token

def fetch_alerts(subscription_id):
    end_time_utc = datetime.now(timezone.utc)
    start_time_utc = end_time_utc - timedelta(minutes=1)
    start_time_str = start_time_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    end_time_str = end_time_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.AlertsManagement/alerts?customTimeRange={start_time_str}/{end_time_str}&api-version=2019-05-05-preview"
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    try:
        requests.packages.urllib3.disable_warnings()
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            alerts = response.json()
            filtered_alerts = []
            for alert in alerts.get("value", []):
                properties = alert.get("properties", {})
                essentials = properties.get("essentials", {})
                severity = essentials.get("severity", None)
                target_resource = essentials.get("targetResource", None)
                target_resource_name = essentials.get("targetResourceName", None)
                alert_name = alert.get("name")
                filtered_alert = {
                    "severity": severity,
                    "targetResource": target_resource,
                    "targetResourceName": target_resource_name,
                    "name": alert_name
                }
                filtered_alerts.append(filtered_alert)
            return filtered_alerts
        else:
            print("Failed to fetch alerts. Status code:", response.status_code)
            print("Response:", response.text)
            return None
    except Exception as e:
        print("An error occurred:", e)
        return None

def save_to_json(alerts):
    if alerts:
        with open("alerts.json", "w") as f:
            json.dump(alerts, f)
        print("Filtered alerts saved to 'alerts.json' file.")

def map_severity(severity):
    if severity == "Sev0":
        return "Critical"
    elif severity == "Sev1":
        return "Critical"
    elif severity == "Sev2":
        return "Warning"
    elif severity == "Sev3":
        return "Informational"
    else:
        return severity

def fetch_detailed_logs(target_resource_name, alert_description):
    """Fetch detailed logs from Application Insights API based on alert type."""
    app_id = app_insights_resource_map.get(target_resource_name)
    if not app_id:
        return f"No Application Insights resource ID found for {target_resource_name}."
    
    base_url = f"https://api.applicationinsights.io/v1/apps/{app_id}/query"
    headers = {
        "X-Api-Key": app_insights_api_key,
        "Content-Type": "application/json"
    }
    alert_description_lower = alert_description.lower()
    end_time = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    start_time = (datetime.now(timezone.utc) - timedelta(minutes=10)).strftime("%Y-%m-%dT%H:%M:%SZ")
    
    # Construct KQL query based on alert type
    if "exception" in alert_description_lower:
        query = f"""
        exceptions
        | where timestamp >= datetime('{start_time}') and timestamp <= datetime('{end_time}')
        | project timestamp, problemId, outerMessage, details, outerStackTrace
        | order by timestamp desc
        | take 5
        """
    elif "dependency" in alert_description_lower or "dapendency" in alert_description_lower:
        query = f"""
        dependencies
        | where timestamp >= datetime('{start_time}') and timestamp <= datetime('{end_time}')
        | where success == false
        | project timestamp, name, target, resultCode, duration, data
        | order by timestamp desc
        | take 5
        """
    else:
        query = f"""
        requests
        | where timestamp >= datetime('{start_time}') and timestamp <= datetime('{end_time}')
        | project timestamp, name, duration, resultCode, success, url
        | order by timestamp desc
        | take 5
        """
    
    payload = {"query": query}
    try:
        response = requests.post(base_url, headers=headers, json=payload)
        if response.status_code == 200:
            data = response.json()
            rows = data.get("tables", [{}])[0].get("rows", [])
            if not rows:
                return "No relevant logs found for the alert."
            
            log_output = f"Detailed Logs for {target_resource_name}:\n\n"
            if "exception" in alert_description_lower:
                log_output += "Exceptions:\n"
                for row in rows:
                    log_output += f"Timestamp: {row[0]}\nProblem: {row[1]}\nMessage: {row[2]}\nDetails: {row[3]}\nStack Trace: {row[4]}\n{'-'*50}\n"
            elif "dependency" in alert_description_lower or "dapendency" in alert_description_lower:
                log_output += "Dependency Failures:\n"
                for row in rows:
                    log_output += f"Timestamp: {row[0]}\nName: {row[1]}\nTarget: {row[2]}\nResult Code: {row[3]}\nDuration: {row[4]}ms\nData: {row[5]}\n{'-'*50}\n"
            else:
                log_output += "Requests:\n"
                for row in rows:
                    log_output += f"Timestamp: {row[0]}\nName: {row[1]}\nDuration: {row[2]}ms\nResult Code: {row[3]}\nSuccess: {row[4]}\nURL: {row[5]}\n{'-'*50}\n"
            return log_output
        else:
            print(f"Failed to fetch logs for {target_resource_name}. Status code: {response.status_code}")
            return f"Unable to retrieve logs for {target_resource_name}. Status: {response.status_code}"
    except Exception as e:
        print(f"Error fetching logs for {target_resource_name}: {e}")
        return f"Error retrieving logs for {target_resource_name}: {str(e)}"

def send_email(api_name, owner_email, severity, alert_description, cc_email, log_details):
    severity_label = map_severity(severity)
    smtp_server = appinsight_report_config.SMTP_SERVER
    smtp_port = appinsight_report_config.SMTP_PORT
    sender_email = appinsight_report_config.SENDER_EMAIL
    password = appinsight_report_config.SENDER_PASSWORD

    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = owner_email
    msg["Cc"] = cc_email
    msg["Subject"] = f"Alert Fired: Severity:{severity_label} | {alert_description}"

    body = f"""
    <html>
    <body>
    <p>Hi Team,</p>
    <p>We have received below alert from the subjected API. Kindly review and action accordingly. Alert details are as below,</p>
    <p><b>Severity:</b> {severity_label}</p>
    <p><b>Source:</b> {api_name}</p>
    <p><b>Alert Description:</b> {alert_description}</p>
    <p><b>Log Details:</b><br><pre>{log_details}</pre></p>
    <p>Thanks & Regards,<br>EMS Team</p>
    </body>
    </html>
    """
    msg.attach(MIMEText(body, "html"))

    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(sender_email, password)
        server.send_message(msg)

def fetch_data_from_onedrive():
    authority = 'https://login.microsoftonline.com/' + tenant_id
    app = ConfidentialClientApplication(client_id, authority=authority, client_credential=client_secret)
    result = app.acquire_token_for_client(scopes=['https://graph.microsoft.com/.default'])
    access_token = result['access_token']
    my_files_url = f'https://graph.microsoft.com/v1.0/users/{user_id}/drive/root/children'
    response = requests.get(my_files_url, headers={'Authorization': 'Bearer ' + access_token})
    results = response.json()['value']
    for item in results:
        if item['name'] == 'Appinsight_alerts_receipients.xlsx':
            receipient_file = item
            break
    if receipient_file:
        receipient_file_url = receipient_file['@microsoft.graph.downloadUrl']
        receipient_file_response = requests.get(receipient_file_url, headers={'Authorization': 'Bearer ' + access_token})
        if receipient_file_response.status_code == 200:
            receipient_content = BytesIO(receipient_file_response.content)
            receipient_df_1 = pd.read_excel(receipient_content)
            global recep_dict
            recep_dict = dict(zip(receipient_df_1['API_Name'], receipient_df_1['Recipients (To)']))
            global recep_dict2
            recep_dict2 = dict(zip(receipient_df_1['API_Name'], receipient_df_1['Recipients (cc)']))

if __name__ == "__main__":
    try:
        subscription_id = appinsight_report_config.SUBSCRIPTION_ID
        alerts = fetch_alerts(subscription_id)
        save_to_json(alerts)
        api_names_not_found = []
        for alert in alerts:
            fetch_data_from_onedrive()
            owner_email = recep_dict.get(alert.get("targetResourceName"))
            cc_email = recep_dict2.get(alert.get("targetResourceName"))
            if owner_email is None:
                print(f"No owner email found for API: {alert.get('targetResourceName')}.")
                api_names_not_found.append(alert.get('targetResourceName'))
                owner_email = appinsight_report_config.DEFAULT_EMAIL
            
            target_resource_name = alert.get("targetResourceName")
            severity = alert.get("severity")
            alert_description = alert.get("name")
            
            # Fetch detailed logs instead of screenshot
            log_details = fetch_detailed_logs(target_resource_name, alert_description)
            send_email(target_resource_name, owner_email, severity, alert_description, cc_email, log_details)
            print(f"Alert email sent for {target_resource_name} with log details")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
```