<powershell>
Install-WindowsFeature -name Web-Server -IncludeManagementTools
echo "<html><body><h1>Hello from Windows VM</h1></body></html>" | Out-File -FilePath C:\inetpub\wwwroot\index.html
</powershell>
