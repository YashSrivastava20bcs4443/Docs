# Set your Azure resource group and DNS zone names
$resourceGroupName = "demo-resource-YS"
$dnsZoneName = "my.internal.dns"

# Define the subnets where you want to create DNS records
$subnets = @("inc1-prd-prl-app-snet01")

# # Log in to Azure using device authentication
# Connect-AzAccount -UseDeviceAuthentication
# Set your Azure resource group and DNS zone names


# Retrieve all VMs in the resource group
$vms = Get-AzVM -ResourceGroupName $resourceGroupName

# Debug: Output all VMs and their tags
Write-Output "All VMs in the Resource Group:"
$vms | ForEach-Object {
    Write-Output "VM Name: $($_.Name)"
    Write-Output "Tags: $($_.Tags.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" })"
}

# Filter VMs based on the 'service' tag with value 'app_server'
$filteredVms = $vms | Where-Object {
    $_.Tags["service"] -eq "app_server"
}

# Debug: Output the filtered VMs
Write-Output "Filtered VMs based on 'service' Tag:"
$filteredVms | ForEach-Object { Write-Output $_.Name }

# Check if any VMs were retrieved
if ($filteredVms.Count -eq 0) {
    Write-Output "No VMs found with the specified 'service' tag."
    exit
}

# Loop through each filtered VM to create DNS records
foreach ($vm in $filteredVms) {
    # Get the VM's network interface(s)
    $networkInterfaceIds = $vm.NetworkProfile.NetworkInterfaces.Id
    foreach ($networkInterfaceId in $networkInterfaceIds) {
        $networkInterfaceName = $networkInterfaceId.Split('/')[-1]
        $networkInterface = Get-AzNetworkInterface -ResourceGroupName $resourceGroupName -Name $networkInterfaceName

        # Get the private IP address and subnet ID
        $ipConfigurations = $networkInterface.IpConfigurations

        foreach ($ipConfig in $ipConfigurations) {
            $privateIp = $ipConfig.PrivateIpAddress
            $subnetId = $ipConfig.Subnet.Id
            $subnetName = $subnetId.Split('/')[-1]

            # Check if the subnet is in the list of specified subnets
            if ($subnets -contains $subnetName) {
                # Debug: Output the network interface, subnet, and private IP
                Write-Output "VM Name: $($vm.Name)"
                Write-Output "Network Interface Name: $networkInterfaceName"
                Write-Output "Subnet: $subnetName"
                Write-Output "Private IP: $privateIp"

                # Set the DNS record name (you can customize this as needed)
                $dnsRecordName = $vm.Name

                # Debug: Output the DNS record being created
                Write-Output "Creating DNS record: $dnsRecordName with IP: $privateIp"

                # Create the DNS record in the private DNS zone
                New-AzPrivateDnsRecordSet -ResourceGroupName $resourceGroupName -ZoneName $dnsZoneName -Name $dnsRecordName -RecordType A -Ttl 3600 -PrivateDnsRecords (New-AzPrivateDnsRecordConfig -Ipv4Address $privateIp)
            }
        }
    }
}

Write-Output "DNS records have been created for the VMs in the specified subnets."
