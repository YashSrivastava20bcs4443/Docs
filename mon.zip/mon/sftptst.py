import paramiko
import posixpath
import re
from datetime import datetime

# SFTP server credentials
host = '172.23.1.107'
port = 22
username = 'fwbackup'
password = '2002'

# Directories
source_folder = '/upload/Network_devices_Backup'
destination_folder = posixpath.join(source_folder, 'monthly_Backup')

# Mapping of dates to month names
date_to_month = {
    '01-31': 'January',
    '02-28': 'February',
    '03-31': 'March',
    '04-30': 'April',
    '05-31': 'May',
    '06-30': 'June',
    '07-31': 'July',
    '08-31': 'August',
    '09-30': 'September',
    '10-31': 'October',
    '11-30': 'November',
    '12-31': 'December'
}

# Connect to SFTP server
transport = paramiko.Transport((host, port))
transport.connect(username=username, password=password)
sftp = paramiko.SFTPClient.from_transport(transport)

# Ensure the destination folder exists
def ensure_dir_exists(sftp, path):
    """Ensure that a directory exists on the SFTP server."""
    try:
        sftp.stat(path)
    except IOError:
        sftp.mkdir(path)

ensure_dir_exists(sftp, destination_folder)

# Function to check if the date in filename matches specific dates
def is_specific_date(filename):
    match = re.search(r'\d{4}-\d{2}-\d{2}', filename)
    if match:
        date_str = match.group()
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        month_day = date_obj.strftime('%m-%d')
        return month_day if month_day in date_to_month else None
    return None

# Copy the specific date files to the corresponding folder in the destination
for folder in sftp.listdir(source_folder):
    folder_path = posixpath.join(source_folder, folder)
    if folder == 'monthly_Backup':
        continue
    if sftp.stat(folder_path).st_mode & 0o040000:  # Check if it's a directory
        for file in sftp.listdir(folder_path):
            month_day = is_specific_date(file)
            if month_day:
                month_name = date_to_month[month_day]
                source_file_path = posixpath.join(folder_path, file)
                dest_folder_path = posixpath.join(destination_folder, month_name)
                
                # Ensure the destination subfolder exists
                ensure_dir_exists(sftp, dest_folder_path)
                
                destination_file_path = posixpath.join(dest_folder_path, file)
                with sftp.file(source_file_path, 'rb') as source_file:
                    with sftp.file(destination_file_path, 'wb') as dest_file:
                        dest_file.write(source_file.read())
                print(f'Copied {source_file_path} to {destination_file_path}')

# Close the SFTP connection
sftp.close()
transport.close()
