const { error, Console } = require('console');
const express = require('express');
const fs = require('fs');
const csvjson = require('csvjson');
const { Pool } = require('pg');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());
const pool = new Pool({
host: '10.7.32.134',
user: 'postgres',
password: 'automation@123',
database: 'postgres',
port: 5432
});

app.get('/api/stats', async (req, res) => {
try {
const { startDate, endDate, portal, tfn } = req.query;
console.log(typeof startDate);
console.log(startDate);
console.log(endDate);
let query = `
SELECT
COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4') AS ivr_offered,
COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric = 0 AND "abandoned" = 'True' AND "preQueueSeconds"::numeric > 0) AS ivr_abandoned,
COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric > 0 AND "abandoned" = 'True') AS queue_abandoned,
COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric = 0 AND "abandoned" = 'False' AND "preQueueSeconds"::numeric > 0) AS closed_by_ivr,
COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "abandoned" = 'True' AND "preQueueSeconds"::numeric < 10) AS abandoned_in_10_sec,
COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "abandoned" = 'True' AND "preQueueSeconds"::numeric > 10) AS abandoned_in_over_10_sec,
COUNT(*) FILTER (WHERE "masterContactId" = "contactId" AND "isOutbound" = 'False' AND "mediaTypeId" = '4' AND "abandoned" = 'False' AND "agentSeconds"::numeric > 0) AS answered_calls
FROM contact_mapped_data
WHERE to_date("contactStartDate", 'YYYY-MM-DD') BETWEEN $1 AND $2
`;

const queryParams = [startDate, endDate];

if (portal) {
query += ' AND "Portal" = $3';
queryParams.push(portal);
}

if (tfn) {
query += ' AND "TFN Type" = $4';
queryParams.push(tfn);
}

const result = await pool.query(query, queryParams);
console.log(result.rows[0]);
res.json(result.rows[0]);
} catch (err) {
console.error('Error fetching stats:', err);
res.status(500).json({ error: 'Internal Server Error' });
}
});

app.get('/api/detail', async (req, res) => {
try {
const { category, startDate, endDate, portal, tfn } = req.query;
let query = `
SELECT "TFN", "Description", COUNT(*) AS count
FROM contact_mapped_data
WHERE to_date("contactStartDate", 'YYYY-MM-DD') BETWEEN $1 AND $2
`;

const queryParams = [startDate, endDate];

if (portal) {
query += ' AND "Portal" = $3';
queryParams.push(portal);
}

if (tfn) {
query += ' AND "TFN Type" = $4';
queryParams.push(tfn);
}

switch(category) {
case 'ivr_offered':
query += ' AND "masterContactId" = "contactId" AND "isOutbound" = \'False\' AND "mediaTypeId" = \'4\'';
break;
case 'ivr_abandoned':
query += ' AND "masterContactId" = "contactId" AND "isOutbound" = \'False\' AND "mediaTypeId" = \'4\' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric = 0 AND "abandoned" = \'True\' AND "preQueueSeconds"::numeric > 0';
break;
case 'queue_abandoned':
query += ' AND "masterContactId" = "contactId" AND "isOutbound" = \'False\' AND "mediaTypeId" = \'4\' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric > 0 AND "abandoned" = \'True\'';
break;
case 'closed_by_ivr':
query += ' AND "masterContactId" = "contactId" AND "isOutbound" = \'False\' AND "mediaTypeId" = \'4\' AND "agentSeconds"::numeric = 0 AND "inQueueSeconds"::numeric = 0 AND "abandoned" = \'False\' AND "preQueueSeconds"::numeric > 0';
break;
case 'abandoned_under_10':
query += ' AND "masterContactId" = "contactId" AND "isOutbound" = \'False\' AND "mediaTypeId" = \'4\' AND "abandoned" = \'True\' AND "preQueueSeconds"::numeric < 10';
break;
case 'abandoned_over_10':
query += ' AND "masterContactId" = "contactId" AND "isOutbound" = \'False\' AND "mediaTypeId" = \'4\' AND "abandoned" = \'True\' AND "preQueueSeconds"::numeric > 10';
break;
case 'answered_calls':
query += ' AND "masterContactId" = "contactId" AND "isOutbound" = \'False\' AND "mediaTypeId" = \'4\' AND "abandoned" = \'False\' AND "agentSeconds"::numeric > 0';
break;
default:
return res.status(400).json({ error: 'Invalid category' });
}

query += ' GROUP BY "TFN", "Description"';
const result = await pool.query(query, queryParams);
res.json(result.rows);
} catch (err) {
console.error('Error fetching detail data:', err);
res.status(500).json({ error: 'Internal Server Error' });
}
});

const PORT = 3000;
app.listen(PORT, () => {
console.log(`Server running on port ${PORT}`);
});