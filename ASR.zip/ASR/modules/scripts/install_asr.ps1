# Download and install the ASR provider and MARS agent
$providerUrl = "https://aka.ms/downloadazuremigrate"
$providerPath = "C:\\AzureSiteRecoveryProvider.exe"
Invoke-WebRequest -Uri $providerUrl -OutFile $providerPath
Start-Process -FilePath $providerPath -ArgumentList "/quiet" -Wait

$marsAgentUrl = "https://aka.ms/AzureBackup_Agent"
$marsAgentPath = "C:\\MARSAgentInstaller.exe"
Invoke-WebRequest -Uri $marsAgentUrl -OutFile $marsAgentPath
Start-Process -FilePath $marsAgentPath -ArgumentList "/quiet" -Wait

# Register the server with the Recovery Services Vault
$vaultCredentialsPath = "C:\\path\\to\\vaultcredentials.vaultcredentials"
& "C:\\Program Files\\Microsoft Azure Recovery Services Agent\\bin\\RegisterServer.exe" /Register /Config $vaultCredentialsPath /NoReboot

# Configure replication settings (optional, adjust as needed)
$job = Start-ASRJob -JobName "Configure-Replication" -ReplicationServer $replicationServer -VM $vm -Policy $policy
