// Fetch data from API endpoints
async function fetchData(endpoint) {
    try {
        const response = await fetch(`http://localhost:3000/api/${endpoint}`);
        if (!response.ok) {
            throw new Error(`Failed to fetch data from ${endpoint}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Error fetching ${endpoint}:`, error);
        throw error; // Re-throw to handle in renderCharts
    }
}

// Queue Status Distribution (Stacked Bar Chart)
function renderQueueStatusDistribution(data) {
    const trace1 = {
        x: data.labels,
        y: data.preQueueSeconds,
        name: 'Pre Queue',
        type: 'bar',
        marker: { color: 'rgba(75, 192, 192, 1)' }
    };
    const trace2 = {
        x: data.labels,
        y: data.inQueueSeconds,
        name: 'In Queue',
        type: 'bar',
        marker: { color: 'rgba(54, 162, 235, 1)' }
    };
    const trace3 = {
        x: data.labels,
        y: data.postQueueSeconds,
        name: 'Post Queue',
        type: 'bar',
        marker: { color: 'rgba(153, 102, 255, 1)' }
    };
    const layout = {
        barmode: 'stack',
        title: 'Queue Status Distribution',
        xaxis: { title: 'Contact ID' },
        yaxis: { title: 'Seconds' },
        responsive: true,
        height: 400
    };
    Plotly.newPlot('queueStatusDistribution', [trace1, trace2, trace3], layout);
}

// Average Queue Time Per Campaign (Stacked Bar Chart)
function renderAverageQueueTimePerCampaign(data) {
    const trace1 = {
        x: data.labels,
        y: data.avgPreQueue,
        name: 'Avg Pre Queue',
        type: 'bar',
        marker: { color: 'rgba(75, 192, 192, 1)' }
    };
    const trace2 = {
        x: data.labels,
        y: data.avgInQueue,
        name: 'Avg In Queue',
        type: 'bar',
        marker: { color: 'rgba(54, 162, 235, 1)' }
    };
    const trace3 = {
        x: data.labels,
        y: data.avgPostQueue,
        name: 'Avg Post Queue',
        type: 'bar',
        marker: { color: 'rgba(153, 102, 255, 1)' }
    };
    const layout = {
        barmode: 'stack',
        title: 'Average Queue Time Per Campaign',
        xaxis: { title: 'Campaign Name' },
        yaxis: { title: 'Average Seconds' },
        responsive: true,
        height: 400
    };
    Plotly.newPlot('averageQueueTimePerCampaign', [trace1, trace2, trace3], layout);
}

// Top 5 Agents By Call Volume (Horizontal Bar Chart)
function renderTop5AgentsByCallVolume(data) {
    const trace = {
        x: data.callVolume,
        y: data.labels,
        type: 'bar',
        orientation: 'h',
        marker: { color: 'rgba(75, 192, 192, 1)' }
    };
    const layout = {
        title: 'Top 5 Agents By Call Volume',
        xaxis: { title: 'Call Volume' },
        yaxis: { title: 'Agent ID' },
        responsive: true,
        height: 400
    };
    Plotly.newPlot('top5AgentsByCallVolume', [trace], layout);
}

// Agent Average Handle Time (Bar Chart)
function renderAgentAverageHandleTime(data) {
    const trace = {
        x: data.labels,
        y: data.avgHandleTime,
        type: 'bar',
        marker: { color: 'rgba(75, 192, 192, 1)' } // Fixed typo: removed invalid character
    };
    const layout = {
        title: 'Agent Average Handle Time',
        xaxis: { title: 'Agent ID' },
        yaxis: { title: 'Average Handle Time (Seconds)' },
        responsive: true,
        height: 400
    };
    Plotly.newPlot('agentAverageHandleTime', [trace], layout);
}

// Calls By End Reason (Pie Chart)
function renderCallsByEndReason(data) {
    const trace = {
        labels: data.labels,
        values: data.callCount,
        type: 'pie',
        marker: {
            colors: [
                'rgba(75, 192, 192, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)'
            ]
        }
    };
    const layout = {
        title: 'Calls By End Reason',
        responsive: true,
        height: 400
    };
    Plotly.newPlot('callsByEndReason', [trace], layout);
}

// Short Abandon Vs Completed Calls (Stacked Bar Chart)
function renderShortAbandonVsCompletedCalls(data) {
    const shortAbandonLabels = Object.keys(data.shortAbandon);
    const completedLabels = Object.keys(data.completed);
    const allLabels = [...new Set([...shortAbandonLabels, ...completedLabels])];

    const trace1 = {
        x: allLabels,
        y: allLabels.map(label => data.shortAbandon[label] || 0),
        name: 'Short Abandon',
        type: 'bar',
        marker: { color: 'rgba(255, 99, 132, 1)' }
    };
    const trace2 = {
        x: allLabels,
        y: allLabels.map(label => data.completed[label] || 0),
        name: 'Completed',
        type: 'bar',
        marker: { color: 'rgba(75, 192, 192, 1)' }
    };
    const layout = {
        barmode: 'stack',
        title: 'Short Abandon Vs Completed Calls',
        xaxis: { title: 'End Reason' },
        yaxis: { title: 'Call Count' },
        responsive: true,
        height: 400
    };
    Plotly.newPlot('shortAbandonVsCompletedCalls', [trace1, trace2], layout);
}

// Calls Per Campaign (Bar Chart)
function renderCallsPerCampaign(data) {
    const trace = {
        x: data.labels,
        y: data.callCount,
        type: 'bar',
        marker: { color: 'rgba(75, 192, 192, 1)' }
    };
    const layout = {
        title: 'Calls Per Campaign',
        xaxis: { title: 'Campaign Name' },
        yaxis: { title: 'Call Count' },
        responsive: true,
        height: 400
    };
    Plotly.newPlot('callsPerCampaign', [trace], layout);
}

// Transfer Type Breakdown (Pie Chart)
function renderTransferTypeBreakdown(data) {
    const trace = {
        labels: data.labels,
        values: data.callCount,
        type: 'pie',
        marker: {
            colors: [
                'rgba(75, 192, 192, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)'
            ]
        }
    };
    const layout = {
        title: 'Transfer Type Breakdown',
        responsive: true,
        height: 400
    };
    Plotly.newPlot('transferTypeBreakdown', [trace], layout);
}

// Calls Routed By Skill (Bar Chart)
function renderCallsRoutedBySkill(data) {
    const trace = {
        x: data.labels,
        y: data.callCount,
        type: 'bar',
        marker: { color: 'rgba(75, 192, 192, 1)' }
    };
    const layout = {
        title: 'Calls Routed By Skill',
        xaxis: { title: 'Skill Name' },
        yaxis: { title: 'Call Count' },
        responsive: true,
        height: 400
    };
    Plotly.newPlot('callsRoutedBySkill', [trace], layout);
}

// Loading Spinner Functions (kept but not functional without spinner in charts.html)
function showLoadingSpinner() {
    console.log('Loading started...'); // Placeholder since no spinner in charts.html
}

function hideLoadingSpinner() {
    console.log('Loading finished...');
}

// Render all charts with error handling
async function renderCharts() {
    showLoadingSpinner();
    try {
        const queueStatusDistributionData = await fetchData('queueStatusDistribution');
        renderQueueStatusDistribution(queueStatusDistributionData);

        const averageQueueTimePerCampaignData = await fetchData('averageQueueTimePerCampaign');
        renderAverageQueueTimePerCampaign(averageQueueTimePerCampaignData);

        const top5AgentsByCallVolumeData = await fetchData('top5AgentsByCallVolume');
        renderTop5AgentsByCallVolume(top5AgentsByCallVolumeData);

        const agentAverageHandleTimeData = await fetchData('agentAverageHandleTime');
        renderAgentAverageHandleTime(agentAverageHandleTimeData);

        const callsByEndReasonData = await fetchData('callsByEndReason');
        renderCallsByEndReason(callsByEndReasonData);

        const shortAbandonVsCompletedCallsData = await fetchData('shortAbandonVsCompletedCalls');
        renderShortAbandonVsCompletedCalls(shortAbandonVsCompletedCallsData);

        const callsPerCampaignData = await fetchData('callsPerCampaign');
        renderCallsPerCampaign(callsPerCampaignData);

        const transferTypeBreakdownData = await fetchData('transferTypeBreakdown');
        renderTransferTypeBreakdown(transferTypeBreakdownData);

        const callsRoutedBySkillData = await fetchData('callsRoutedBySkill');
        renderCallsRoutedBySkill(callsRoutedBySkillData);
    } catch (error) {
        console.error('Error rendering charts:', error);
        // Optionally alert user if desired: alert('Failed to load charts.');
    } finally {
        hideLoadingSpinner();
    }
}

// Initialize charts on page load
window.onload = renderCharts;