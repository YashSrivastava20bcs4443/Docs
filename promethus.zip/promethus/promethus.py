import requests
from datetime import datetime, timedelta

# Prometheus server details
prometheus_url = 'http://192.168.31.193:9090/api/v1/query_range'

# Queries for CPU and Memory usage
cpu_query = 'rate(node_cpu_seconds_total[5m])'
memory_query = 'node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes'

# Time range parameters
end_time = datetime.now()  # Current time
start_time = end_time - timedelta(days=15)  # 15 days ago

# Convert times to UNIX timestamps
start_timestamp = int(start_time.timestamp())
end_timestamp = int(end_time.timestamp())

# Function to fetch range data from Prometheus
def fetch_prometheus_range_data(query, start, end, step):
    params = {
        'query': query,
        'start': start,
        'end': end,
        'step': step
    }
    response = requests.get(prometheus_url, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Failed to fetch data: {response.status_code}")
        return None

# Fetch CPU data for last 15 days with 1 hour step
cpu_data = fetch_prometheus_range_data(cpu_query, start_timestamp, end_timestamp, '1h')
if cpu_data:
    print("CPU Data:", cpu_data)

# Fetch Memory data for last 15 days with 1 hour step
memory_data = fetch_prometheus_range_data(memory_query, start_timestamp, end_timestamp, '1h')
if memory_data:
    print("Memory Data:", memory_data)
